//
//  ToFart.m
//  WatchMeFart
//
//  Created by Ber Jr on 2016-07-15.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import "ToFart.h"

@implementation ToFart

@end
