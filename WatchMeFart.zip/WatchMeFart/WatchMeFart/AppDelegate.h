//
//  AppDelegate.h
//  WatchMeFart
//
//  Created by Ber Jr on 2016-07-13.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

