//
//  ViewController.m
//  WatchMeFart
//
//  Created by Ber Jr on 2016-07-13.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import "ViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>


@import SpriteKit;
@import UIKit;
@import WatchConnectivity;



@interface ViewController () <WCSessionDelegate>
@property (strong, nonatomic) NSMutableArray *completeFart;
@property (weak, nonatomic) UITableView *mainTableView;
@end

@implementation ViewController
{
    AVAudioPlayer *player;
    NSString *transferedCompleteFart;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIImageView *backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"toxicHaxard.png"]];
    [self.view addSubview:backgroundView];
    
    
    transferedCompleteFart = @"0";
    
    
    
    if ([WCSession isSupported])
    {
        WCSession* session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
    }
    
    if(!self.completeFart) {
        self.completeFart = [[NSMutableArray alloc] init];
    }
    
    [self.mainTableView reloadData];
    
    NSThread* myThread = [[NSThread alloc] initWithTarget:self
                                                  selector:@selector(loopingThread)
                                                    object:nil];
    
    [myThread start];
    //[self loopingThread];

}

- (void)loopingThread{
    
    while( 1 )
    {
        if ( [transferedCompleteFart isEqualToString:@"1"] ){
            [self makeFartSound];
            transferedCompleteFart = @"0";
        }
        
        [NSThread sleepForTimeInterval:0.1];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)makeFartSound {
    
    int random = arc4random_uniform(2);
    
    NSString *soundFilePath;
    
    if ( random == 0 )
    {
       soundFilePath = [NSString stringWithFormat:@"%@/fart0.mp3", [[NSBundle mainBundle]resourcePath] ] ;
    }
    else if ( random == 1 )
    {
       soundFilePath = [NSString stringWithFormat:@"%@/fart1.mp3", [[NSBundle mainBundle]resourcePath] ] ;
    }
    else if ( random == 2 )
    {
       soundFilePath = [NSString stringWithFormat:@"%@/fart2.mp3", [[NSBundle mainBundle]resourcePath] ] ;
    }
    
    NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL
                                                    error:nil];
      
    [player play];

}

- (void)session:(nonnull WCSession *)session didReceiveMessage:(nonnull NSDictionary *)message
   replyHandler:(nonnull void (^)(NSDictionary * __nonnull))replyHandler {
    transferedCompleteFart = [message objectForKey:@"counterValue"];
    
    if(!self.completeFart)
    {
        self.completeFart = [[NSMutableArray alloc] init];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.completeFart addObject:transferedCompleteFart];
        [self.mainTableView reloadData];
    });
}
@end
